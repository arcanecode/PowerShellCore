# Extensions suggested you install in VSCode

PowerShell
Markdown All in One
Markdown Preview Enhanced
SQL Server (mssql)
Bash Debug